from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .actions import (
    generate_project_report,
    load_project_config,
    load_status_summary,
    refresh_project_status_action,
    run_project_action,
    status_summary,
    validate_project,
    validation_summary,
)
from .chat import run_chat
from .estimate import estimate_runtime
from .gui import run_gui
from .remote import build_directory_scan_command, build_upload_commands
from .wizard import run_wizard


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="rnaseq-agent",
        description="Interactive RNA-seq analysis agent.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    wizard = subparsers.add_parser("wizard", help="Start the interactive project wizard.")
    wizard.add_argument(
        "--output-dir",
        default="runs",
        help="Directory where project configs will be written. Default: runs",
    )

    chat = subparsers.add_parser(
        "chat",
        help="Start the conversational project-session agent.",
    )
    chat.add_argument(
        "--output-dir",
        default="runs",
        help="Directory where project configs will be written. Default: runs",
    )

    gui = subparsers.add_parser("gui", help="Start the graphical project setup interface.")
    gui.add_argument(
        "--output-dir",
        default="runs",
        help="Directory where project configs will be written. Default: runs",
    )

    estimate = subparsers.add_parser("estimate", help="Estimate runtime from a saved project config.")
    estimate.add_argument("config", help="Path to project.json")

    scan = subparsers.add_parser(
        "scan-command",
        help="Print an optional SSH command for checking a remote FASTQ directory.",
    )
    scan.add_argument("config", help="Path to project.json")

    upload = subparsers.add_parser(
        "upload-command",
        help="Print commands that upload local FASTQ files to the server.",
    )
    upload.add_argument("config", help="Path to project.json")

    validate = subparsers.add_parser(
        "validate-local",
        help="Check whether local FASTQ files referenced by the project config exist.",
    )
    validate.add_argument("config", help="Path to project.json")

    run = subparsers.add_parser(
        "run",
        help="Validate, upload, submit, poll, download, and optionally notify for a project.",
    )
    run.add_argument("config", help="Path to project.json")
    run.add_argument(
        "--no-wait",
        action="store_true",
        help="Submit the remote job and return without polling for completion.",
    )

    status = subparsers.add_parser(
        "status",
        help="Refresh project status from the server and print the current state.",
    )
    status.add_argument("config", help="Path to project.json")
    status.add_argument(
        "--cached",
        action="store_true",
        help="Only print the status already stored in project.json without contacting the server.",
    )

    report = subparsers.add_parser(
        "report",
        help="Generate a Markdown summary report for a project run.",
    )
    report.add_argument("config", help="Path to project.json")
    report.add_argument(
        "--output",
        help="Path to write the Markdown report. Default: <project_dir>/report.md",
    )

    return parser


def main(argv: list[str] | None = None) -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")

    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "wizard":
        run_wizard(Path(args.output_dir))
        return 0

    if args.command == "chat":
        run_chat(Path(args.output_dir))
        return 0

    if args.command == "gui":
        run_gui(Path(args.output_dir))
        return 0

    if args.command == "estimate":
        config = load_project_config(Path(args.config))
        runtime = estimate_runtime(config)
        print(runtime.summary)
        return 0

    if args.command == "scan-command":
        config = load_project_config(Path(args.config))
        server = config["server"]
        remote_dir = config["samples"]["remote_data_dir"]
        command = build_directory_scan_command(server["host"], server["user"], remote_dir)
        print(command.description)
        print(f"{command.command[0]} {command.command[1]} \"{command.command[2]}\"")
        return 0

    if args.command == "upload-command":
        config = load_project_config(Path(args.config))
        for command in build_upload_commands(config):
            print(command.description)
            print(_format_command(command.command))
        return 0

    if args.command == "validate-local":
        _, result = validate_project(Path(args.config))
        print(f"Checked FASTQ files: {result.checked_files}")
        for line in validation_summary(result):
            print(line)
        return 0 if result.ok else 1

    if args.command == "run":
        try:
            outcome = run_project_action(Path(args.config), wait=not args.no_wait)
        except Exception as exc:
            print(str(exc), file=sys.stderr)
            return 1
        print(outcome.message)
        print(f"Project directory: {outcome.project_dir}")
        return 0 if outcome.state in {"submitted", "completed"} else 1

    if args.command == "status":
        if args.cached:
            lines = load_status_summary(Path(args.config))
        else:
            status = refresh_project_status_action(Path(args.config))
            lines = status_summary(status)
        for line in lines:
            print(line)
        return 0

    if args.command == "report":
        output = generate_project_report(
            Path(args.config),
            output_path=Path(args.output) if args.output else None,
        )
        print(f"Report written to: {output}")
        return 0

    parser.error(f"Unknown command: {args.command}")
    return 2


def _format_command(command: list[str]) -> str:
    return " ".join(_quote_arg(arg) for arg in command)


def _quote_arg(arg: str) -> str:
    if not arg or any(char.isspace() for char in arg):
        return '"' + arg.replace('"', '\\"') + '"'
    return arg
